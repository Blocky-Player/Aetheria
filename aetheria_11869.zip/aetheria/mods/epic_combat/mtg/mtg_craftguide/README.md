Minetest Game mod: mtg_craftguide
=================================

Adds a "Recipes" tab to the inventory. Click an item to see it's recipes.
Click again to show usages.

Based on [craftguide](https://github.com/minetest-mods/craftguide).

Authors of media
----------------

paramat (CC BY-SA 3.0):

* craftguide_clear_icon.png
* craftguide_next_icon.png
* craftguide_prev_icon.png
* craftguide_search_icon.png

Neuromancer (CC BY-SA 3.0):

* craftguide_furnace.png

Wuzzy (CC BY-SA 3.0):

* craftguide_shapeless.png
