Minetest Mod - Grenade [shooter_grenade]
========================================

Depends: shooter

Adds simple hand grenades.

Crafting
========

S = Steel Ingot  [default:steel_ingot]
G = Gunpowder    [shooter:gunpowder]

Grenade: [shooter_grenade:grenade]

+---+---+
| G | S |
+---+---+

