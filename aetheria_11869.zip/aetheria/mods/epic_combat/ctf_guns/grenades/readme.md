# grenades
Adds an API that allows for easily making grenades

See grenades_basic for the grenades this mod used to have

License of code: **MIT**
