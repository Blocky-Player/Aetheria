License of source code
----------------------

Copyright (c) 2021 block_plyer.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

code blocky_player MIT 

For more details:
https://opensource.org/licenses/MIT

Textures
--------
Blocky Player: red_steel_block.png
Blocky Player: red_steel_ingot.png
Blocky Player: red_steel_axe.png
Blocky Player: red_steel_sword.png
Blocky Player: red_steel_pickaxe.png
Blocky Player: red_steel_shovel.png
Blocky Player: red_steel_red_steel_necklace.png
Blocky Player: red_steel_red_steel_necklace_preview.png
Blocky Player: red_steel_red_steel_necklace_inv.png

MIT
----
Blocky Player: init.lua

MIT		               