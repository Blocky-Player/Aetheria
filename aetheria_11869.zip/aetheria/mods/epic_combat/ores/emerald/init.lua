-----------------
-- Ores/blocks --
-----------------

minetest.register_node("emerald:emerald_block", {
    description = ("Emerald Block"),
    tiles = {"emerald_block.png"},
    is_ground_content = true,
    groups = {cracky = 3},
})

minetest.register_node("emerald:emerald_ore", {
	description = ("Emerald Ore"),
	tiles = {"default_stone.png^emerald_ore.png"},
	is_ground_content = true,
	groups = {cracky = 3},
	drop = "emerald:emerald",
})

minetest.register_craftitem("emerald:emerald", {
	description = ("Emerald"),
	inventory_image = "emerald.png",
})

      minetest.register_ore({
	          ore_type       = "scatter",
	          ore            = "emerald:emerald_ore",
	          wherein        = "default:stone",
	          clust_scarcity = 15 * 15 * 15,
	          clust_num_ores = 4,
	          clust_size     = 3,
	          y_max          = -500,
	          y_min          = -31000,
	   })
	   
	  minetest.register_ore({
		      ore_type       = "scatter",
		      ore            = "emerald:emerald_ore",
		      wherein        = "default:stone",
		      clust_scarcity = 17 * 17 * 17,
		      clust_num_ores = 4,
		      clust_size     = 3,
		      y_max          = -500,
		      y_min          = -255,
	   })

	  minetest.register_ore({
		       ore_type       = "scatter",
		       ore            = "emerald:emerald_ore",
		       wherein        = "default:stone",
		       clust_scarcity = 15 * 15 * 15,
		       clust_num_ores = 4,
		       clust_size     = 3,
		       y_max          = -500,
		       y_min          = -31000,
	   })

minetest.register_craft({
	output = "emerald:emerald_block",
	recipe = {
		{"emerald:emerald", "emerald:emerald", "emerald:emerald"},
		{"emerald:emerald", "emerald:emerald", "emerald:emerald"},
		{"emerald:emerald", "emerald:emerald", "emerald:emerald"},
	}
})

minetest.register_craft({
	output = "emerald:emerald 9",
	recipe = {
		{"emerald:emerald_block"},
	}
})

