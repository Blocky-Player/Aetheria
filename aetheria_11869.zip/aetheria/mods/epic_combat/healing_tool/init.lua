
minetest.register_tool("healing_tool:bandage", {
	description = ("Apple of healing"),
	inventory_image = "bandage.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=0,
		groupcaps={
			cracky = {times={[0]=1.60}, uses=35, maxlevel=1},
		},
		damage_groups = {fleshy=-1},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 0, flammable = 0}
})


minetest.register_craft({
	output = "daggers:diamond_dagger",
	recipe = {
		{"", "default:apple 4"},
		{"default:apple 2", ""},
	}
})


